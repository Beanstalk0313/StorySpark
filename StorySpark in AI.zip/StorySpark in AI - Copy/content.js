
/**
 * StorySpark Immersive Driver - Content Script
 * Protocol v2.4: Overlay + Classic UI Hybrid
 */

const MARKERS = {
    ANALYSIS: /ANALYSIS_START/i,
    IMAGE: /IMAGE_PROMPT/i,
    REGEN: /REGEN\s*:\s*TRUE/i 
};

const LOGO_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><g transform="translate(1.2, 3.3) scale(0.9)"><path fill="currentColor" d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path fill="currentColor" d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></g></svg>`;

let currentChapters = [];
let bookMetadata = { title: "New Story", plot: "A new adventure..." };
let isInitialized = false;
let isOverlayVisible = false;
let scrapeTimeout = null;
let isWriting = false; 

// --- Message Listener ---
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "init_storyspark") {
        isInitialized = true;
        initOverlay();
        toggleOverlay(true);
        scrapeAndRefresh();
        sendResponse({status: "ok"});
    }
});

// --- UI Construction ---

function getPlatformName() {
    const host = window.location.hostname;
    if (host.includes('google')) return 'Gemini';
    if (host.includes('openai') || host.includes('chatgpt')) return 'ChatGPT';
    if (host.includes('bing') || host.includes('copilot')) return 'Copilot';
    if (host.includes('claude')) return 'Claude';
    return 'AI';
}

function initOverlay() {
    if (document.getElementById('ss-overlay')) return;

    const platform = getPlatformName();

    const overlay = document.createElement('div');
    overlay.id = 'ss-overlay';
    overlay.className = 'glass-mode'; 
    
    overlay.innerHTML = `
        <div class="ss-nav">
            <div class="ss-nav-brand">
                <div style="color:var(--ss-accent); display:flex; align-items:center;">${LOGO_SVG}</div>
                <span class="ss-brand-text">StorySpark</span>
                <span class="ss-nav-divider">/</span>
                <div class="ss-title-container">
                    <input type="text" id="ss-book-title" value="${bookMetadata.title}" placeholder="Book Title..." />
                    <span class="ss-platform-tag">in ${platform}</span>
                </div>
            </div>
            <div class="ss-nav-controls">
                <button id="ss-export-btn" class="ss-btn ss-btn-secondary">Download Book</button>
                <button id="ss-min-btn" class="ss-btn ss-btn-ghost" title="Minimize to view chat">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                </button>
            </div>
        </div>
        
        <div class="ss-main" id="ss-scroller">
            <div class="ss-reader" id="ss-reader-content">
                <div style="text-align:center; margin-top: 100px; opacity: 0.6;">
                    <h3>Ready to Write</h3>
                    <p>Type your first prompt below to begin your story.</p>
                </div>
            </div>
        </div>

        <div class="ss-footer">
            <div class="ss-input-wrapper">
                <textarea id="ss-input" class="ss-input" placeholder="What happens next? (Type here to drive the AI)"></textarea>
                <button id="ss-send" class="ss-send-btn">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                </button>
            </div>
        </div>
    `;

    document.body.appendChild(overlay);

    const floatBtn = document.createElement('div');
    floatBtn.id = 'ss-float-btn';
    floatBtn.innerHTML = LOGO_SVG;
    floatBtn.style.display = 'none'; 
    floatBtn.onclick = () => toggleOverlay(true);
    document.body.appendChild(floatBtn);

    document.getElementById('ss-min-btn').onclick = () => toggleOverlay(false);
    document.getElementById('ss-export-btn').onclick = handleDownloadClick;
    
    const titleInput = document.getElementById('ss-book-title');
    titleInput.oninput = (e) => { bookMetadata.title = e.target.value; };

    const sendBtn = document.getElementById('ss-send');
    const input = document.getElementById('ss-input');
    
    const handleSend = () => {
        const text = input.value.trim();
        if (!text) return;
        
        isWriting = true;
        updateStatus("Sending to AI...");
        sendMessageToPage(text);
        input.value = '';
    };

    sendBtn.onclick = handleSend;
    input.onkeydown = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };
}

function toggleOverlay(show) {
    const overlay = document.getElementById('ss-overlay');
    const floatBtn = document.getElementById('ss-float-btn');
    isOverlayVisible = show;

    if (show) {
        overlay.classList.remove('hidden-ui');
        floatBtn.style.display = 'none';
        setTimeout(scrollToBottom, 100);
    } else {
        overlay.classList.add('hidden-ui');
        floatBtn.style.display = 'flex';
    }
}

function updateStatus(msg, subtext = "") {
    const reader = document.getElementById('ss-reader-content');
    let statusEl = document.getElementById('ss-status-indicator');
    
    if (!statusEl) {
        statusEl = document.createElement('div');
        statusEl.id = 'ss-status-indicator';
        statusEl.style.cssText = "text-align: center; padding: 20px; color: var(--ss-accent); font-weight: 600; opacity: 0.8;";
        reader.appendChild(statusEl);
    }
    
    if (msg) {
        statusEl.innerHTML = `
            <div style="display:flex; flex-direction:column; align-items:center; gap:5px;">
                <div><span class="ss-loading-pulse"></span> ${msg}</div>
                ${subtext ? `<div style="font-size:12px; font-weight:400; opacity:0.7">${subtext}</div>` : ''}
            </div>
        `;
        statusEl.style.display = 'block';
        scrollToBottom();
    } else {
        statusEl.style.display = 'none';
    }
}

function updateReaderUI() {
    const reader = document.getElementById('ss-reader-content');
    if (!reader) return;

    const statusEl = document.getElementById('ss-status-indicator');
    reader.innerHTML = '';
    
    if (currentChapters.length === 0) {
        reader.innerHTML = `
            <div style="text-align:center; margin-top: 100px; opacity: 0.6;">
                <h3>Ready to Write</h3>
                <p>Type your prompt below. The extension will drive the AI for you.</p>
            </div>
        `;
    } else {
        currentChapters.forEach((ch, idx) => {
            const div = document.createElement('div');
            div.className = 'ss-chapter';
            
            let htmlContent = ch.content
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/\*(.*?)\*/g, '<em>$1</em>')
                .replace(/\n/g, '<br>');

            div.innerHTML = `
                <div class="ss-chapter-header">
                    <span class="ss-chapter-title">Segment ${idx + 1}</span>
                    <span class="ss-chapter-meta">${ch.importance} Priority</span>
                </div>
                <div class="ss-chapter-content">${htmlContent}</div>
                ${ch.imagePrompt ? `
                    <div class="ss-chapter-actions">
                        <button class="ss-overlay-img-btn" data-prompt="${ch.imagePrompt.replace(/"/g, '&quot;')}">
                            🎨 Generate Illustration
                        </button>
                    </div>
                ` : ''}
                ${ch.summary ? `<div style="margin-top:30px; padding-top:15px; border-top:1px dashed var(--ss-border); font-size:12px; color:var(--ss-text); opacity:0.7"><strong>Summary:</strong> ${ch.summary}</div>` : ''}
            `;
            reader.appendChild(div);
        });

        reader.querySelectorAll('.ss-overlay-img-btn').forEach(btn => {
            btn.onclick = (e) => {
                const prompt = e.target.getAttribute('data-prompt');
                triggerIllustration(prompt);
            };
        });
    }

    if (statusEl) reader.appendChild(statusEl);
    scrollToBottom();
}

function scrollToBottom() {
    const scroller = document.getElementById('ss-scroller');
    if(scroller) scroller.scrollTo({ top: scroller.scrollHeight, behavior: 'smooth' });
}

// --- HISTORY FETCHING & EXPORT ---

async function fetchAllHistory() {
    const candidates = Array.from(document.querySelectorAll('div, main'));
    let scroller = null;
    let maxScroll = 0;

    candidates.forEach(el => {
        const overflowY = window.getComputedStyle(el).overflowY;
        if ((overflowY === 'auto' || overflowY === 'scroll') && el.scrollHeight > el.clientHeight) {
            if (el.scrollHeight > maxScroll) {
                maxScroll = el.scrollHeight;
                scroller = el;
            }
        }
    });

    if (!scroller) scroller = document.documentElement;
    if (!scroller) return;

    let retries = 0;
    const maxRetries = 20; 
    let lastHeight = scroller.scrollHeight;
    
    updateStatus("Fetching entire story history...", "Scrolling up to load old messages");

    while (retries < maxRetries) {
        scroller.scrollTop = 0;
        await new Promise(r => setTimeout(r, 1500));
        const newHeight = scroller.scrollHeight;
        if (newHeight <= lastHeight) {
             await new Promise(r => setTimeout(r, 1000));
             if (scroller.scrollHeight <= lastHeight) break; 
        }
        lastHeight = newHeight;
        retries++;
        updateStatus("Fetching entire story history...", `Loaded batch ${retries}...`);
    }
    
    scrapeAndRefresh();
    updateStatus(null);
}

async function handleDownloadClick() {
    updateStatus("Preparing download...");
    try {
        await fetchAllHistory();
        if (currentChapters.length === 0) {
            alert("No story segments found even after scrolling. Please ensure the chat is loaded.");
            updateStatus(null);
            return;
        }
        const book = {
            title: bookMetadata.title,
            request: { type: "CONTINUATION", plot: bookMetadata.plot, bookLength: "INFINITE" },
            chapters: currentChapters.map((c, i) => ({ ...c, index: i })),
            promptHistory: [], format: 'storyspark-book-file', version: '2.4', createdAt: new Date().toISOString()
        };
        const blob = new Blob([JSON.stringify(book, null, 2)], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `${bookMetadata.title.replace(/[^a-z0-9]/gi, '_')}.ssbf`;
        a.click();
    } catch (e) {
        console.error(e);
        alert("Error fetching history. Downloading current view only.");
        updateStatus(null);
    }
}

// --- Automation Driver ---

function sendMessageToPage(text) {
    const inputSelectors = [
        'div[contenteditable="true"]', 
        '#prompt-textarea',
        'textarea', 
        'cib-serp'
    ];
    let inputEl = null;
    
    for(let sel of inputSelectors) {
        inputEl = document.querySelector(sel);
        if(inputEl) break;
    }
    
    if(!inputEl || inputEl.tagName === 'CIB-SERP') {
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
        let node;
        while(node = walker.nextNode()) {
            if(node.shadowRoot) {
                const innerInput = node.shadowRoot.querySelector('#searchbox') || node.shadowRoot.querySelector('textarea') || node.shadowRoot.querySelector('[contenteditable]');
                if (innerInput) {
                    inputEl = innerInput;
                    break; 
                }
            }
        }
    }

    if(inputEl) {
        inputEl.focus();
        
        if (inputEl.tagName === 'TEXTAREA') inputEl.value = '';
        else inputEl.innerText = '';

        document.execCommand('insertText', false, text);
        
        inputEl.dispatchEvent(new Event('input', { bubbles: true }));
        inputEl.dispatchEvent(new Event('change', { bubbles: true }));

        setTimeout(() => {
            const sendSelectors = [
                'button[aria-label="Send message"]', 
                'button[data-testid="send-button"]', 
                '.send-button',
                'button[type="submit"]'
            ];
            
            let sendBtn = null;
            const root = inputEl.getRootNode();
            if (root) {
                for(let sel of sendSelectors) {
                    sendBtn = root.querySelector(sel);
                    if(sendBtn) break;
                }
            }
            
            if(sendBtn) {
                sendBtn.click();
            } else {
                const enterEvent = new KeyboardEvent('keydown', {
                    bubbles: true, cancelable: true, keyCode: 13, key: 'Enter'
                });
                inputEl.dispatchEvent(enterEvent);
            }
            
            updateStatus("AI is writing...");
            
        }, 300);
    } else {
        alert("StorySpark Driver Error: Could not find the chat input box. Please report this site.");
        isWriting = false;
        updateStatus(null);
    }
}

function triggerIllustration(promptText) {
    const textToSend = promptText ? `@Illustration ${promptText}` : "@Illustration";
    sendMessageToPage(textToSend);
}

// --- Scraper & Classic UI Injection ---

function getMessages() {
    const sels = [
        'message-content', 
        '.markdown.prose',
        '.agent-turn-content', 
        'div[data-message-author-role="assistant"]'
    ];
    let msgs = Array.from(document.querySelectorAll(sels.join(',')));

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
    let node;
    while (node = walker.nextNode()) {
        if (node.shadowRoot) {
            sels.forEach(s => msgs.push(...Array.from(node.shadowRoot.querySelectorAll(s))));
        }
    }

    // Dedup logic
    let uniqueMsgs = [...new Set(msgs)];
    uniqueMsgs = uniqueMsgs.filter(m => {
        const containsAnother = uniqueMsgs.some(other => other !== m && m.contains(other));
        return !containsAnother;
    });

    return uniqueMsgs;
}

function injectClassicUI(node) {
    if (node.getAttribute('data-ss-classic-injected') === 'true') return;
    
    const html = node.innerHTML;
    
    if (html.includes('ANALYSIS_START')) {
        const parts = html.split('ANALYSIS_START');
        if (parts.length > 1) {
            const content = parts[0];
            const meta = 'ANALYSIS_START' + parts[1];
            
            let imgBtnHtml = '';
            const imgMatch = meta.match(/IMAGE_PROMPT\s*([^<]*)/i);
            if (imgMatch) {
                const imgPrompt = imgMatch[1].replace(/<[^>]*>/g, '').trim();
                imgBtnHtml = `
                    <div class="ss-classic-actions">
                        <button class="ss-classic-img-btn" data-prompt="${imgPrompt.replace(/"/g, '&quot;')}">
                            🎨 Generate Illustration
                        </button>
                    </div>
                `;
            }

            node.innerHTML = `
                ${content}
                <div class="ss-classic-metadata" style="display:none; color:#888; font-size:10px; border:1px dashed #ccc; padding:5px; margin-top:10px;">
                    ${meta}
                </div>
                ${imgBtnHtml}
                <div class="ss-classic-toggle">
                    <button class="ss-toggle-btn">Show/Hide Metadata</button>
                </div>
            `;
            
            const imgBtn = node.querySelector('.ss-classic-img-btn');
            if (imgBtn) {
                imgBtn.onclick = (e) => triggerIllustration(e.target.getAttribute('data-prompt'));
            }
            
            const toggleBtn = node.querySelector('.ss-toggle-btn');
            if (toggleBtn) {
                toggleBtn.onclick = (e) => {
                    const metaDiv = e.target.closest('div').parentElement.querySelector('.ss-classic-metadata');
                    if (metaDiv) metaDiv.style.display = metaDiv.style.display === 'none' ? 'block' : 'none';
                };
            }
            
            node.setAttribute('data-ss-classic-injected', 'true');
        }
    }
}

function getPureText(node) {
    const clone = node.cloneNode(true);
    const uiElements = clone.querySelectorAll('.ss-classic-actions, .ss-classic-toggle, .ss-badge, .ss-metadata-container');
    uiElements.forEach(el => el.remove());
    return clone.textContent || "";
}

function scrapeAndRefresh() {
    const nodes = getMessages();
    let found = [];

    nodes.forEach((node, idx) => {
        if (node.classList.contains('ss-ignored')) return;

        injectClassicUI(node);

        const text = getPureText(node);
        const hasAnalysis = MARKERS.ANALYSIS.test(text);
        const hasImage = MARKERS.IMAGE.test(text);

        if (hasAnalysis || hasImage) {
            let content = text;
            let summary = "No summary.";
            let importance = "MEDIUM";
            let imagePrompt = "";
            let isRegen = false;

            const analysisMatch = text.match(/ANALYSIS_START([^]*?)(?=IMAGE_PROMPT|$)/i);
            if (analysisMatch) {
                const meta = analysisMatch[1];
                content = text.split(/ANALYSIS_START/i)[0].trim();
                
                if (MARKERS.REGEN.test(meta)) isRegen = true;

                const impM = meta.match(/IMP:\s*(HIGH|MEDIUM|LOW)/i);
                const sumM = meta.match(/SUM:\s*([^|[\n<]*)/i);
                if (impM) importance = impM[1].toUpperCase();
                if (sumM) summary = sumM[1].trim();
            }

            const imageMatch = text.match(/IMAGE_PROMPT([^]*?)$/i);
            if (imageMatch) {
                imagePrompt = imageMatch[1].trim();
                if (content.includes("IMAGE_PROMPT")) content = content.split(/IMAGE_PROMPT/i)[0].trim();
            }
            
            if (found.length === 0 && idx === 0 && bookMetadata.title === "New Story") {
                const titleMatch = content.match(/^#\s(.*?)$/m);
                if (titleMatch) {
                    bookMetadata.title = titleMatch[1].trim();
                    const titleInput = document.getElementById('ss-book-title');
                    if (titleInput) titleInput.value = bookMetadata.title;
                }
            }

            const segment = { id: `seg-${idx}`, content, summary, importance, imagePrompt };

            if (isRegen && found.length > 0) {
                found[found.length - 1] = segment;
            } else {
                found.push(segment);
            }
        }
    });

    if (JSON.stringify(found) !== JSON.stringify(currentChapters)) {
        currentChapters = found;
        updateReaderUI();
        
        if (isWriting) {
            isWriting = false;
            updateStatus(null);
        }
    }
}

function init() {
    const observer = new MutationObserver((mutations) => {
        if (!isInitialized) return;
        
        let shouldScrape = false;
        for (const m of mutations) if (m.addedNodes.length > 0 || m.type === 'characterData') { shouldScrape = true; break; }
        
        if (shouldScrape) {
            if (scrapeTimeout) clearTimeout(scrapeTimeout);
            scrapeTimeout = setTimeout(scrapeAndRefresh, 1000);
        }
    });
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
}

init();
