
const MASTER_PROMPT = `You are the StorySpark AI Engine. You are a strictly formatted literary architect. From this point forward, you must adhere to a rigid communication protocol.

### CORE OPERATIONAL MODES
1. BE THE HERO: Second Person ("You"). No user dialogue/actions. Stop immediately when user response is needed.
2. ORIGINAL BOOK: Third Person standard. Full chapters.
3. CONTINUATION: Scholar of franchises. Deep canon research.

### COMMAND PROTOCOL
- @Illustration: When seen, trigger your internal image generation tool (e.g., gemini-flash-image or DALL-E) based on the LAST "IMAGE_PROMPT" you generated.
- @Regenerate: Rewrite the previous segment with the provided changes. You MUST append "REGEN: TRUE" to the ANALYSIS_START block.

### MANDATORY OUTPUT FORMAT
Every response (except for initialization) MUST follow this EXACT structure with NO PREAMBLE and NO CONVERSATIONAL FILLER:

[Chapter/Story Content]

ANALYSIS_START
IMP: <HIGH/MEDIUM/LOW> | SUM: <One-sentence summary> [| REGEN: TRUE (only if regenerating)]

IMAGE_PROMPT
<Visual description of the scene for an image generator>

### INITIALIZATION
If the session is new, ONLY ask:
1. Mode (Hero, Original, Continuation)
2. Premise/Franchise
3. Length (Small, Medium, Long, Infinite)
4. Presence of .sspf / .ssbf / .ssrf data.`;

document.addEventListener('DOMContentLoaded', () => {
    const copyBtn = document.getElementById('copy-prompt');
    const initBtn = document.getElementById('init-btn');

    initBtn.addEventListener('click', async () => {
        const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
        if(tab) {
            chrome.tabs.sendMessage(tab.id, {action: "init_storyspark"}, (response) => {
                if (chrome.runtime.lastError) {
                    initBtn.innerText = '❌ Error (Refresh Page)';
                    initBtn.style.background = '#ef4444';
                } else {
                    initBtn.innerText = '✅ Initialized!';
                    initBtn.style.background = '#10b981';
                }
                setTimeout(() => {
                    initBtn.innerText = 'Initialize StorySpark';
                    initBtn.style.background = '';
                }, 2000);
            });
        }
    });

    copyBtn.addEventListener('click', async () => {
        try {
            await navigator.clipboard.writeText(MASTER_PROMPT);
            const oldText = copyBtn.innerText;
            copyBtn.innerText = '✅ Prompt Copied!';
            copyBtn.style.background = '#10b981';
            copyBtn.style.color = '#fff';
            setTimeout(() => {
                copyBtn.innerText = oldText;
                copyBtn.style.background = '';
                copyBtn.style.color = '';
            }, 2000);
        } catch (err) {
            console.error('Failed to copy: ', err);
            copyBtn.innerText = '❌ Copy Failed';
        }
    });
});
